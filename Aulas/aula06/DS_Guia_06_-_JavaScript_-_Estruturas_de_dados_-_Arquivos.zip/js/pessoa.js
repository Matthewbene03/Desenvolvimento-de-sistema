class Pessoa {
  constructor(cpf, nome, idade) {
    this.cpf = cpf;
    this.nome = nome;
    this.idade = idade;
  }
}




