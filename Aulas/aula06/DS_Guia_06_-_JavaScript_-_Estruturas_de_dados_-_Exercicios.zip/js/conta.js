class Conta {
  constructor(numero, nome, saldo) {
    this.numero = numero;
    this.nome = nome;
    this.saldo = saldo;
  }
}




