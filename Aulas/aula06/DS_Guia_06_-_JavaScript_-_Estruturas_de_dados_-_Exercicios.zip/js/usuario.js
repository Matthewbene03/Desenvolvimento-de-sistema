class Usuario {
  constructor(login, senha) {
    this.login = login;
    this.senha = senha;
  }
}




