class Vaga {
  constructor(numero, placa, login) {
    this.numero = numero;
    this.placa = placa;
    this.login = login;
  }
}




